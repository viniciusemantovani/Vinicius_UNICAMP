function extra1()


%definicao da planta
m=0.5;
k=20;
b=1.5;
G=tf([1],[m b k]);

z1 = 5-8i;
z2 = 5+8i;
p1 = 0;
p2 = 0;
ganhoDeBusca = 4;
ganhosFixos = [z1 z2 p1 p2];
faixaBusca = linspace(0.001,5,100);
tempoSimulacao = 0:0.01:5;
[saidas] = calculaSaida(faixaBusca,G,ganhosFixos,ganhoDeBusca,tempoSimulacao);

gravarVideo=1;
animateStep(gravarVideo,saidas,tempoSimulacao,faixaBusca,ganhoDeBusca,ganhosFixos);

%__________________________________________________________________________
function [saida] = calculaSaida(faixaBusca,G, ganhosFixos,ganhoDeBusca,tempoSimulacao)

saida = [];
for i=1:size(faixaBusca,2)    
    ganhosFixos(ganhoDeBusca)=faixaBusca(i);
    
    s = tf([1 0], 1);
    
    z1 = ganhosFixos(1);
    z2 = ganhosFixos(2);
    p1 = ganhosFixos(3);
    p2 = ganhosFixos(4);

    C = (s + z1)*(s + z2) / ( (s + p1)*(s + p2) );
    Gcl=feedback(C*G,1);    
    s=step(Gcl,tempoSimulacao);
    saida = [saida;s'];
end


%__________________________________________________________________________
function animateStep(gravarVideo,saida,tempo,k,ganhoDeBusca,ganhosFixos)

fig = figure();

set(fig, 'Position', [100, 100, 800, 600]);  % Exemplo: 800x600 pixels


box=[0 tempo(end) 0 1.5];

f=1;
while f <= size(saida,1)
    
    hold on;  

    axis(box);
    s = printGanhos(k(f),ganhoDeBusca,ganhosFixos);
    text(box(2)-2.5,box(3)+1,s);
    
    plot(tempo,saida(f,:));
    
    xlabel t;
    ylabel y;
    axis(box);
    hold off;      
    if gravarVideo
        F{f} = getframe();                
    else
        pause(0.1);
    end	    
    clf(fig);    
    fprintf('f=%d -> k=%.3f\n',f,k(f));
    f=f+1;    
end
if gravarVideo
    geraVideo('extra1.avi',F);
end
close(fig);

%__________________________________________________________________________
function geraVideo(nome,F)

writerObj = VideoWriter(nome,'Motion JPEG AVI');
open(writerObj);
minL=1e10;
minC=1e10;
for f=1:size(F,2)
    if size(F{f}.cdata,1) < minL
        minL = size(F{f}.cdata,1);
    end
    if size(F{f}.cdata,2)  < minC
        minC = size(F{f}.cdata,2);
    end
end
for f=1:size(F,2)
    F2.colormap = [];
    for i=1:3
        F2.cdata(1:minL,1:minC,i) =F{f}.cdata(1:minL,1:minC,i);
    end
    writeVideo(writerObj,F2);
end
close(writerObj);

%__________________________________________________________________________
function s = printGanhos(k,ganhoDeBusca,ganhosFixos)

if ganhoDeBusca==1
    s=sprintf('z1 =%.2f z2=%.2f+%.2fi p1=%.2f p2=%.2f\n',k, real(ganhosFixos([2])), imag(ganhosFixos([2])), ganhosFixos([3 4]));
elseif ganhoDeBusca==2
    s=sprintf('z1 =%.2f%.2fi z2=%.2f p1=%.2f p2=%.2f\n',real(ganhosFixos(1)), imag(ganhosFixos(1)), k,ganhosFixos([3 4]));
elseif ganhoDeBusca==3
    s=sprintf('z1=%.2f%.2fi z2=%.2f+%.2fi p1=%.2f p2=%.2f\n',real(ganhosFixos([1])), imag(ganhosFixos([1])), real(ganhosFixos([2])), imag(ganhosFixos([2])),k,ganhosFixos(4));
else
    s=sprintf('z1=%.2f%.2fi z2=%.2f+%.2fi p1=%.2f p2=%.2f\n',real([ganhosFixos([1])]), imag([ganhosFixos([1])]), real([ganhosFixos([2])]), imag([ganhosFixos([2])]), ganhosFixos([3]),k);
end