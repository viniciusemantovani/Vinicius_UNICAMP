function tarefa3_alunos()

m=0.5;
k=20;
b=1.5;

G=tf([1],[m b k]);

%declare seus ganhos aqui
kp=4;
ki=40;
kd=1;
C = pid(kp,ki,kd);
G=feedback(G*C,1);

tempoSimulacao=0:0.1:5;
%degrau unitario
u=ones(1,length(tempoSimulacao))';
%simulacao
y=lsim(G,u,tempoSimulacao);

gravarVideo=1;
videoMassaMola(gravarVideo,tempoSimulacao,y')

%__________________________________________________________________________
function videoMassaMola(gravarVideo,tempo,saida)

fig = figure();

f=1;
tamCar1 = [1 0.7];
tamMola = [0.7];
ori = [0 -1];
while f <= length(saida)       
    y = saida(1,f);
   
    hold on;
    axis equal;
    axis([-1 3.5 -1 1]);
    stringy=sprintf('y = %.2f\n',y);
    text(2.5,0.5,stringy);
    desenhaCarros(ori,y,tamCar1,tamMola);
    
    hold off;    
    if gravarVideo
        F{f} = getframe();
    else
        pause(0.1);
    end    
    fprintf('frame=%d tempo=%.2f s -> [y] = [%.3f]\n',f,tempo(f),y);    
    clf(fig);           
    f=f+1;
end
if gravarVideo
    geraVideo('extra3.avi',F)
end
close(fig);

%__________________________________________________________________________
function geraVideo(nome,F)

writerObj = VideoWriter(nome,'Motion JPEG AVI');
open(writerObj);
minL=1e10;
minC=1e10;
for f=1:size(F,2)
    if size(F{f}.cdata,1) < minL
        minL = size(F{f}.cdata,1);
    end
    if size(F{f}.cdata,2)  < minC
        minC = size(F{f}.cdata,2);
    end
end
for f=1:size(F,2)
    F2.colormap = [];
    for i=1:3
        F2.cdata(1:minL,1:minC,i) =F{f}.cdata(1:minL,1:minC,i);
    end
    writeVideo(writerObj,F2);
end
close(writerObj);

%__________________________________________________________________________
function desenhaCarros(ori,y,tamCar1,tamMola)


%carro 
p1 = [ori(1)+y ori(2)];
p2 = [ori(1)+y + tamCar1(1) ori(2)];
p3 = [ori(1)+y + tamCar1(1) ori(2)+tamCar1(2)];
p4 = [ori(1)+y ori(2)+tamCar1(2)];

pts = [p1;p2;p3;p4];
f=fill(pts(:,1),pts(:,2),'b');

para=1;


%mola 
folgaNaDireita=2;
ro = 0.1;
xa = ori(1)+tamCar1(1)+y; 
ya = ori(2)+tamCar1(2)/2 + 0.1; 
xb = ori(1)+tamCar1(1)+folgaNaDireita; 
yb = ori(2)+tamCar1(2)/2 + 0.1; 
ne = 5; 
a = tamMola(1); 
[xs,ys] = spring(xa,ya,xb,yb,ne,a,ro); 
plot(xs,ys,'LineWidth',2,'Color','r')

% desenha o amortecedor
plot([2.1 2.7], [-0.7 -0.7], 'LineWidth', 1, 'Color', 'k');
plot([2.1 2.7], [-0.9 -0.9], 'LineWidth', 1, 'Color', 'k');
plot([3   2.7], [-0.8 -0.8], 'LineWidth', 1, 'Color', 'k');
plot([2.7 2.7], [-0.7 -0.9], 'LineWidth', 1, 'Color', 'k');

len = 1.2-y/1.8;
plot([xa xa+len], [-0.8 -0.8], 'LineWidth', 1, 'Color', 'k');
plot([xa+len xa+len], [-0.7 -0.9], 'LineWidth', 1, 'Color', 'k');


%fixacao da direita
r=ori(1)+tamCar1(1)+folgaNaDireita;
p1 = [r ori(2)];
p2 = [r+0.1 ori(2)];
p3 = [r+0.1 ori(2)+0.7];
p4 = [r ori(2)+0.7];
pts = [p1;p2;p3;p4];
f=fill(pts(:,1),pts(:,2),'k');

%piso
p1 = [ori(1)-0.1 ori(2)];
p2 = [ori(1)+tamMola(1)+tamCar1(1)+folgaNaDireita, ori(2)];
plot([p1(1) p2(1)],[p1(2) p2(2)],'LineWidth',0.5,'Color','k');
