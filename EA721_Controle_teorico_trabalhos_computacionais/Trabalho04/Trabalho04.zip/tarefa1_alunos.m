function tarefa1_alunos()


%definicao da planta
m=0.5;
k=20;
b=1.5;
G=tf([1],[m b k]);

Kp = 4;
Kd = 1;
ganhoDeBusca=2;
ganhosFixos = [Kp 0 Kd];
faixaBusca = linspace(0.001,50,100);
tempoSimulacao = 0:0.01:5;
[saidas] = calculaSaida(faixaBusca,G,ganhosFixos,ganhoDeBusca,tempoSimulacao);

gravarVideo=1;
animateStep(gravarVideo,saidas,tempoSimulacao,faixaBusca,ganhoDeBusca,ganhosFixos);

%__________________________________________________________________________
function [saida] = calculaSaida(faixaBusca,G, ganhosFixos,ganhoDeBusca,tempoSimulacao)

saida = [];
for i=1:size(faixaBusca,2)    
    ganhosFixos(ganhoDeBusca)=faixaBusca(i);
    C = pid(ganhosFixos(1),ganhosFixos(2),ganhosFixos(3));
    Gcl=feedback(C*G,1);    
    s=step(Gcl,tempoSimulacao);
    saida = [saida;s'];
end


%__________________________________________________________________________
function animateStep(gravarVideo,saida,tempo,k,ganhoDeBusca,ganhosFixos)

fig = figure();

box=[0 tempo(end) 0 1.5];

f=1;
while f <= size(saida,1)
    
    hold on;  

    axis(box);
    s = printGanhos(k(f),ganhoDeBusca,ganhosFixos);
    text(box(2)-2.5,box(3)+1,s);
    
    plot(tempo,saida(f,:));
    
    xlabel t;
    ylabel y;
    axis(box);
    hold off;      
    if gravarVideo
        F{f} = getframe();                
    else
        pause(0.1);
    end	    
    clf(fig);    
    fprintf('f=%d -> k=%.3f\n',f,k(f));
    f=f+1;    
end
if gravarVideo
    geraVideo('tarefa1.avi',F);
end
close(fig);

%__________________________________________________________________________
function geraVideo(nome,F)

writerObj = VideoWriter(nome,'Motion JPEG AVI');
open(writerObj);
minL=1e10;
minC=1e10;
for f=1:size(F,2)
    if size(F{f}.cdata,1) < minL
        minL = size(F{f}.cdata,1);
    end
    if size(F{f}.cdata,2)  < minC
        minC = size(F{f}.cdata,2);
    end
end
for f=1:size(F,2)
    F2.colormap = [];
    for i=1:3
        F2.cdata(1:minL,1:minC,i) =F{f}.cdata(1:minL,1:minC,i);
    end
    writeVideo(writerObj,F2);
end
close(writerObj);

%__________________________________________________________________________
function s = printGanhos(k,ganhoDeBusca,ganhosFixos)

if ganhoDeBusca==1
    s=sprintf('kp = %.2f ki=%.2f kd=%.2f\n',k,ganhosFixos([2 3]));
elseif ganhoDeBusca==2
    s=sprintf('kp = %.2f ki=%.2f kd=%.2f\n',ganhosFixos(1),k,ganhosFixos(3));
else
    s=sprintf('kp = %.2f ki=%.2f kd=%.2f\n',ganhosFixos(1),ganhosFixos(2),k);
end