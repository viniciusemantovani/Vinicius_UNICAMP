function tarefa2_alunos()

Kp = 4;
Kd = 1;
ganhoDeBusca=2;
ganhosFixos = [Kp 0 Kd];
faixaBusca = linspace(0.001,50,100);
[polos] = calculaRaizes(faixaBusca,ganhosFixos,ganhoDeBusca);

kpEscolhido = 10;
gravarVideo=1;
animateRlocus(gravarVideo,polos,faixaBusca,ganhoDeBusca,ganhosFixos,kpEscolhido);

%__________________________________________________________________________
function [polos] = calculaRaizes(faixaBusca,ganhosFixos,ganhoDeBusca)


polos = [];
for i=1:size(faixaBusca,2)    
    ganhosFixos(ganhoDeBusca)=faixaBusca(i);
    kp = ganhosFixos(1);
    ki = ganhosFixos(2);
    kd = ganhosFixos(3);
    
    m = 0.5;
    b = 1.5;
    k = 20;
    raizes = roots([m b+kd k+kp ki]);
    
    %raizes sendo acumuladas na matriz polos (substitua -1 -2 -3 pelas
    %raizes calculadas pelo comando roots.
    polos = [polos; raizes(1) raizes(2) raizes(3)];    
end


%__________________________________________________________________________
function animateRlocus(gravarVideo,polos,faixaBusca,ganhoDeBusca,ganhosFixos,ganhoEscolhido)

cores = {'b','r','g','k','m'};

fig = figure();

box=calculaDimCanvas(polos);
f=1;
while f <= length(polos)       
    
    ganhoVariavel = faixaBusca(f);
    
    s = printGanhos(ganhoVariavel,ganhoDeBusca,ganhosFixos);
    text(box(2)-2.5,box(3)+1,s);
    hold on;  
    grid;    
    xlabel real;
    ylabel imag;    
    %desenha todos os polos até a posicao 'f'
    for i=1:size(polos,2)
        plot(real(polos(1:f,i)),imag(polos(1:f,i)),cores{i});
    end
    %desenha todos os polos na posicao 'f'
    for i=1:size(polos,2)
        plot(real(polos(f,i)),imag(polos(f,i)),strcat(cores{i},'*'));
    end    
    
    axis(box);    
    if gravarVideo
        F{f} = getframe();    
    else
        pause(0.1);
    end	
    clf(fig);    
    fprintf('f=%d -> k=%.3f\n',f,faixaBusca(f));
    f=f+1;    
end
if gravarVideo 
    geraVideo('tarefa2.avi',F);
end
close(fig);

%__________________________________________________________________________
function geraVideo(nome,F)

writerObj = VideoWriter(nome,'Motion JPEG AVI');
open(writerObj);
minL=1e10;
minC=1e10;
for f=1:size(F,2)
    if size(F{f}.cdata,1) < minL
        minL = size(F{f}.cdata,1);
    end
    if size(F{f}.cdata,2)  < minC
        minC = size(F{f}.cdata,2);
    end
end
for f=1:size(F,2)
    F2.colormap = [];
    for i=1:3
        F2.cdata(1:minL,1:minC,i) =F{f}.cdata(1:minL,1:minC,i);
    end
    writeVideo(writerObj,F2);
end
close(writerObj);

%__________________________________________________________________________
function s = printGanhos(k,ganhoDeBusca,ganhosFixos)

if ganhoDeBusca==1
    s=sprintf('kp = %.2f ki=%.2f kd=%.2f\n',k,ganhosFixos([2 3]));
elseif ganhoDeBusca==2
    s=sprintf('kp = %.2f ki=%.2f kd=%.2f\n',ganhosFixos(1),k,ganhosFixos(3));
else
    s=sprintf('kp = %.2f ki=%.2f kd=%.2f\n',ganhosFixos(1),ganhosFixos(2),k);
end

%__________________________________________________________________________
function box=calculaDimCanvas(polos)

box = [1e10 -1e10 1e10 -1e10];
for i=1:length(polos)
    p=polos(i,:);
    xma=max(real(p));
    xmi=min(real(p));
    yma=max(imag(p));
    ymi=min(imag(p));
    if xma > box(2)
        box(2) = xma;
    end
    if xmi < box(1)
        box(1) = xmi;
    end
    if yma > box(4)
        box(4) = yma;
    end
    if ymi < box(3)
        box(3) = ymi;
    end    
end
box(1) = box(1) -1;
box(2) = box(2) +1;
box(3) = box(3) -1;
box(4) = box(4) +1;


